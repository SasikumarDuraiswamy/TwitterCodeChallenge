package com.twitter.challenge.model;

public class Clouds {
    public int cloudiness;

    public int getCloudiness() {
        return cloudiness;
    }
}
