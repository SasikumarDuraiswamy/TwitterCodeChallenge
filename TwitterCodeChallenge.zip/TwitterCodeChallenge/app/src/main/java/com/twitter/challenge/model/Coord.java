package com.twitter.challenge.model;

public class Coord {

    public double lon;
    public double lat;

    public double getLat() {
        return lat;
    }
}
