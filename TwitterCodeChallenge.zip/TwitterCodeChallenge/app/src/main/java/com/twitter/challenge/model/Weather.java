package com.twitter.challenge.model;

public class Weather {
    public double temp;
    public int pressure;
    public int humidity;

    public double getTemp() {
        return temp;
    }

    public int getPressure() {
        return pressure;
    }

    public int getHumidity() {
        return humidity;
    }
}
