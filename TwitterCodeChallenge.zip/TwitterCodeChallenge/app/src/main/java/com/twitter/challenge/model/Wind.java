package com.twitter.challenge.model;

public class Wind {
    public double speed;
    public int deg;

    public double getSpeed() {
        return speed;
    }

    public int getDeg() {
        return deg;
    }
}
